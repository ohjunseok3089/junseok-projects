

-- Stored Prcoedure Code
DELIMITER //
CREATE PROCEDURE prepWindowPrices (
	IN startDate DATE, IN endDate Date, IN duration integer)
    BEGIN

    

    END //
DELIMITER ; 

-- Calling code, remove the double dashes in the beginning when calling the stored procedure
-- set @startDate = '2022-02-20';
-- set @endDate  = '2022-02-24';
-- set @duration = 2;
 
-- call prepWindowPrices(@startDate, @endDate, @duration);
